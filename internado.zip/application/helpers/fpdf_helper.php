<?php
function fpdf()
{
       require('fpdf/CELLpdf.php');
}
?>