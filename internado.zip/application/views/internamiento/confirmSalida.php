<?php?>
<div class='container bg-light my-5 p-5'>
    <div class='alert alert-success'>Archivo Subido Correctamente</div>
    <a href='<?=base_url('internamiento/internadoSalida')?>' class='btn btn-warning'>Regresar</a>
    <a href='<?=base_url('internamiento/viewPDF/'.$nameDoc)?>' class='btn btn-warning' target='_blank'>Visualizar PDF</a>
</div>
<? 