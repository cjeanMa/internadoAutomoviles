<?php
if($placa)
    echo "<div class='alert alert-success'>Vehiculo encontrado</div>";
    else
    echo "<div class='alert alert-danger'>Vehiculo No Encontrado</div>"
?>