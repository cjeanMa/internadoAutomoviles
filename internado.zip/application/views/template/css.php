<!-- Custom styles for this template-->
<link href="<?= base_url() ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="<?= base_url() ?>assets/theme/css/sb-admin-2.min.css" rel="stylesheet">
<link href="<?= base_url() ?>assets/theme/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
<link href="<?=base_url()?>assets/own/css/styles.css" rel="stylesheet">

<!--Estilos necesarios para dataTables-->
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/dataTables/DataTables-1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/dataTables/Buttons-1.6.1/css/buttons.bootstrap4.min.css" rel="stylesheet" />
