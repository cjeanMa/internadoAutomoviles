<div class="container text-center my-5 py-5">

    <img class="rounded" src="<?= base_url('assets/own/img/logo-muni.png') ?>" alt="logo-muni">
    <h2 class="my-5">Bienvenido</h2>
    <h3><?php echo $this->session->user;?></h3>
    <h2>Sistema de Internamiento Vehicular</h2>

</div>