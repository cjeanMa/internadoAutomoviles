<!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Municipalidad Provincial de Puno</span>
            <br>
            <span>Todos los derechos reservados &copy;  2020</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->