let captcha = false;

function captchaConfirm() {
    captcha = true;
    verificarSubmit();
}

function verificarSubmit() {
    if (captcha) {
        $('#submit').attr("disabled", false);
    }
    else {
        $('#submit').attr("disabled", true);
    }
}